
import { Employee } from './employee.model';
import { Image } from './image';


export interface User {
  id_user?: number;
  nom: string;
  prenom: string;
  email: string;

}