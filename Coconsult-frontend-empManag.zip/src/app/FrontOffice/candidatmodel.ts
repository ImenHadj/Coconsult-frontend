
export interface candidat {

        idCandidat: number;
        nom: string;
        prenom: string;
        email: string;
        telephone: string;
        adresse: string;
        nationalite: string;
        genre: string; 
        score:BigInteger;
        showAllDetails: boolean; 
        niveauDetude : string;
        experience : string;
}