export interface Candidat {


nom: string;
prenom: string;
email: string;
telephone: string;
adresse: string;
nationalite: string;
genre: string;
score: number; 
cvUrl:string;
idCandidat : number;
niveauDetude : string;
experience : string;
}