import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-front',
  templateUrl: './footer-front.component.html',
  styleUrls: ['./footer-front.component.css']
})
export class FooterFrontComponent {

}
