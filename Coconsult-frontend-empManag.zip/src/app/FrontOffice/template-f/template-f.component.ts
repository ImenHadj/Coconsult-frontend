import { Component } from '@angular/core';

@Component({
  selector: 'app-template-f',
  templateUrl: './template-f.component.html',
  styleUrls: ['./template-f.component.css']
})
export class TemplateFComponent {

}
