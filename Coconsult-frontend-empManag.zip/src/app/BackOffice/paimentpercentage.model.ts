
export interface paymentpercentage {

    paimenttype: Typepaiment;
    percentage: number;
   
  }
  export enum Typepaiment {

    // Add other payment types as needed
  }
  