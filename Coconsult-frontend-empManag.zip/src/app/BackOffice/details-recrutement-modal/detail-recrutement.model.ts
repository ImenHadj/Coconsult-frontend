export interface DetailRecrutement {
    title: any;
    date: any;
    dateEntretien: string;
    evaluateur: string;
    commentairesEvaluateur: string;
    typeRecrutement: string; // Type de recrutement (offre d'emploi ou étudiant)
    nomCandidat: string; 
  }
  