

export interface monthlypaiment {
  month: number;
  year: number;
  totalPayment: number;

  }
  

  
