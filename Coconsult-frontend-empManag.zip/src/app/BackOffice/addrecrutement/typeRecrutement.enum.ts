export enum TypeRecrutement {
    OFFRE_EMPLOI = 'OFFRE_EMPLOI',
    ETUDIANT = 'ETUDIANT'
  }